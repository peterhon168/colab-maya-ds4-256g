"""Maya's HIP setup regressions; no GPU, network or model downloads required."""
import json
import os
from pathlib import Path
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import MagicMock, patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import maya


class HipSetupTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.rocm = self.root / "rocm"
        (self.rocm / "llvm/bin").mkdir(parents=True)
        (self.rocm / "llvm/bin/clang++").touch()
        (self.rocm / "lib").mkdir()
        (self.rocm / "lib/libhipblas.so").touch()
        self.gpus = [
            {"index": 0, "arch": "gfx1100", "vendor": "amd", "name": "RX 7900 XT", "vram_gb": 20},
            {"index": 1, "arch": "gfx1201", "vendor": "amd", "name": "R9700", "vram_gb": 32},
            {"index": 2, "arch": "gfx1036", "vendor": "amd", "name": "iGPU", "vram_gb": 1},
        ]
        for ctx in (
            patch.object(maya, "ROOT", self.root),
            patch.object(maya, "BUILD", self.root / "build"),
            patch.object(maya, "EXE", self.root / "build/maya"),
            patch.object(maya, "STAMP", self.root / "build/MAYA-BUILD.json"),
            patch.object(maya, "WIN", False),
            patch.dict(os.environ, {"ROCM_PATH": str(self.rocm)}),
            patch.object(maya.S, "amd_gpus", return_value=self.gpus),
            patch.object(maya.S, "gpus", side_effect=AssertionError("HIP must not query NVIDIA")),
            patch.object(maya.S, "is_wsl", return_value=False),
            patch.object(maya.S, "cpu_info", return_value=("test CPU", True, True)),
            patch.object(maya, "mem_gb", return_value=(192, 128)),
            patch.object(maya, "tool_version", return_value=(7, 2)),
            patch.object(maya.shutil, "which", return_value="/usr/bin/c++"),
        ):
            ctx.start()
            self.addCleanup(ctx.stop)
        self.a = SimpleNamespace(backend="hip", gpu=0, gpus=None, no_vision=False, env=[],
                                 port=8099, host=None, api_key=None, gguf_dir=None)

    def test_selects_larger_supported_discrete_card(self):
        self.a.gpu = None
        pc = maya.check_pc(self.a)
        self.assertEqual(pc["gpus"], [self.gpus[1]])
        self.assertEqual(maya.EXE, self.root / "build-hip/maya")

    def test_versioned_llvm_slot_is_found(self) -> None:
        """Gentoo's versioned LLVM slots count as ROCm's compiler."""
        # Gentoo keeps each LLVM version in its own slot: <root>/lib/llvm/22/bin/clang++
        (self.rocm / "llvm/bin/clang++").unlink()
        for v in ("18", "22"):
            slot = self.rocm / f"lib/llvm/{v}/bin/clang++"
            slot.parent.mkdir(parents=True, exist_ok=True)
            slot.touch()
        self.assertEqual(maya.hip_clang(self.rocm), self.rocm / "lib/llvm/22/bin/clang++")
        pc = maya.check_pc(self.a)
        self.assertEqual(pc["rocm"], str(self.rocm.resolve()))

    def test_debian_multiarch_rocm_is_found(self) -> None:
        """Debian/Ubuntu's own ROCm packages: clang in lib/llvm-<N>/bin, hipBLAS in lib/<multiarch>, the device
        bitcode in the LLVM's clang resource folder (handed to clang as HIP_DEVICE_LIB_PATH)."""
        (self.rocm / "llvm/bin/clang++").unlink()
        (self.rocm / "lib/libhipblas.so").unlink()
        clang = self.rocm / "lib/llvm-21/bin/clang++"
        clang.parent.mkdir(parents=True)
        clang.touch()
        (self.rocm / "lib/x86_64-linux-gnu").mkdir()
        (self.rocm / "lib/x86_64-linux-gnu/libhipblas.so.2").touch()
        bitcode = self.rocm / "lib/llvm-21/lib/clang/21/amdgcn/bitcode"
        bitcode.mkdir(parents=True)
        self.assertEqual(maya.hip_clang(self.rocm), clang)
        pc = maya.check_pc(self.a)
        self.assertEqual(pc["rocm"], str(self.rocm.resolve()))
        with patch.dict(os.environ, {}, clear=False):
            os.environ.pop("HIP_DEVICE_LIB_PATH", None)
            _, _, _, env = maya.hip_toolchain({"rocm": str(self.rocm)})
        self.assertEqual(env["HIP_DEVICE_LIB_PATH"], str(bitcode))

    def test_rocm6_refused_unless_allowed(self) -> None:
        with patch.object(maya, "tool_version", return_value=(6, 4)):
            with self.assertRaises(SystemExit):
                maya.check_pc(self.a)
            with patch.dict(os.environ, {"MAYA_HIP_ALLOW_ROCM6": "1"}):
                pc = maya.check_pc(self.a)
        self.assertEqual(pc["rocm"], str(self.rocm.resolve()))

    def test_cpu_without_avx2_warns_and_goes_on(self) -> None:
        """As on CUDA (#32): the CPU expert lane falls back to ggml's kernels, setup does not stop."""
        with patch.object(maya.S, "cpu_info", return_value=("Xeon E5-2695 v2", False, False)):
            pc = maya.check_pc(self.a)
        self.assertEqual(pc["gpus"], [self.gpus[0]])

    def test_rdna2_is_experimental_and_compiled_only_when_chosen(self):
        pc = maya.check_pc(self.a)      # the RX 7900 XT: its own architecture only (#255)
        self.assertEqual(pc["archs"], ["gfx1100"])
        self.gpus.append({"index": 3, "arch": "gfx1030", "vendor": "amd", "name": "Radeon PRO V620", "vram_gb": 32})
        self.a.gpu = 3
        pc = maya.check_pc(self.a)
        self.assertEqual(pc["gpus"], [self.gpus[3]])
        self.assertEqual(pc["archs"], ["gfx1030"])     # no WMMA arch: no rocWMMA needed (ROCm 7 has none)

    def test_rejects_unsupported_card_and_bad_gpu_lists(self):
        self.a.gpu = 2
        with self.assertRaises(SystemExit):
            maya.check_pc(self.a)
        self.a.gpu = None
        for bad in ("0,2", "0,1,2", "1,1", "x"):
            self.a.gpus = bad
            with self.assertRaises(SystemExit):
                maya.check_pc(self.a)

    def test_two_gpu_split_config(self):
        tables = self.root / "tools/hip"
        tables.mkdir(parents=True)
        for arch in ("gfx1100", "gfx1201"):
            (tables / f"{arch}-glm-hipblaslt-100202.txt").write_text(f"STRATA_HIPBLASLT_TUNING_V1 {arch} 100202\n")
        self.a.gpu = None
        self.a.gpus = "0,1"
        pc = maya.check_pc(self.a)
        self.assertEqual([g["index"] for g in pc["gpus"]], [1, 0])   # the larger card first
        p = maya.write_config(self.a, pc, {"lib_dirs": [str(self.rocm / "lib")]},
                              self.root / "pack", "test", 8192, self.root / "data", None)
        cfg = maya.read_json(p)
        self.assertEqual(cfg["gpu"], [1, 0])
        self.assertNotIn("STRATA_GLM_SPLIT", cfg["env"])
        self.assertEqual(cfg["env"]["STRATA_HIPBLASLT_TUNING"],
                         f"{tables / 'gfx1201-glm-hipblaslt-100202.txt'}{os.pathsep}{tables / 'gfx1100-glm-hipblaslt-100202.txt'}")

    def test_config_selects_hip_and_preserves_user_tuning(self):
        pc = maya.check_pc(self.a)
        self.a.env = ["STRATA_GLM_RESERVE_MB=4096"]
        p = maya.write_config(self.a, pc, {"lib_dirs": [str(self.rocm / "lib")]},
                              self.root / "pack", "test", 8192, self.root / "data", None)
        cfg = maya.read_json(p)
        self.assertEqual(cfg["backend"], "hip")
        self.assertEqual(cfg["gpu"], [0])
        self.assertEqual(cfg["env"]["STRATA_GLM_SPLIT"], "0")
        self.assertEqual(cfg["env"]["STRATA_GLM_RESERVE_MB"], "4096")
        self.assertEqual(cfg["exe"], str(self.root / "build-hip/maya"))
        self.assertNotIn("vision", cfg)

    def test_config_again_keeps_the_servers_own_settings(self):
        # a GLM setup run again dropped the config's host, API key, CORS origins and MCP servers (the DeepSeek, MiniMax
        # and Qwen setups keep them): a PC set up for its network was back on 127.0.0.1 without a key
        pc = {"backend": "hip", "gpus": [self.gpus[0]]}   # (what check_pc gives; the config's own settings are the point)
        first = maya.write_config(self.a, pc, {}, self.root / "pack", "test", 8192, self.root / "data", None)
        own = {"host": "0.0.0.0", "api_key": "k", "cors_origins": ["http://x"], "mcp_servers": {"m": {"url": "u"}}}
        first.write_text(json.dumps({**maya.read_json(first), **own}))
        again = maya.read_json(maya.write_config(self.a, pc, {}, self.root / "pack", "test", 8192, self.root / "data",
                                                 None))
        self.assertEqual({k: again.get(k) for k in own}, own)
        self.a.host, self.a.api_key = "127.0.0.1", "k2"   # given now: they win
        again = maya.read_json(maya.write_config(self.a, pc, {}, self.root / "pack", "test", 8192, self.root / "data",
                                                 None))
        self.assertEqual((again["host"], again["api_key"], again["cors_origins"]), ("127.0.0.1", "k2", ["http://x"]))

    def test_config_prompt_defaults_and_tuning_table(self):
        tables = self.root / "tools/hip"
        tables.mkdir(parents=True)
        (tables / "gfx1100-glm-hipblaslt-100202.txt").write_text("STRATA_HIPBLASLT_TUNING_V1 gfx1100 100202\n")
        (tables / "gfx1201-glm-hipblaslt-100202.txt").write_text("STRATA_HIPBLASLT_TUNING_V1 gfx1201 100202\n")
        (tables / "gfx1100-glm-hipblaslt-100401.txt").write_text("STRATA_HIPBLASLT_TUNING_V1 gfx1100 100401\n")
        # a second table for one version (another build's solution numbers) comes after that version's own file
        (tables / "gfx1100-glm-hipblaslt-100401-b.txt").write_text("STRATA_HIPBLASLT_TUNING_V1 gfx1100 100401\n")
        pc = maya.check_pc(self.a)
        self.a.env = ["STRATA_GLM_PREFILL_SUB=512"]
        p = maya.write_config(self.a, pc, {"lib_dirs": [str(self.rocm / "lib")]},
                              self.root / "pack", "test", 8192, self.root / "data", None)
        env = maya.read_json(p)["env"]
        self.assertNotIn("STRATA_GLM_PREFILL_CHUNK", env)
        self.assertEqual(env["STRATA_GLM_PREFILL_SUB"], "512")   # the user's setting wins
        self.assertEqual(env["STRATA_GLM_PREFILL_MB"], "4096")
        self.assertEqual(env["STRATA_GLM_RESERVE_MB"], "3072")
        self.assertEqual(env["STRATA_GLM_RAM_HEADROOM_GB"], "16")
        self.assertEqual(env["STRATA_HIPBLASLT_TUNING"].split(os.pathsep),
                         [str(tables / "gfx1100-glm-hipblaslt-100202.txt"),
                          str(tables / "gfx1100-glm-hipblaslt-100401.txt"),
                          str(tables / "gfx1100-glm-hipblaslt-100401-b.txt")])
        # Keep the runtime's exact-version choice; an explicit operator table still wins.
        self.a.env.append("STRATA_HIPBLASLT_TUNING=/selected/table.txt")
        p = maya.write_config(self.a, pc, {"lib_dirs": [str(self.rocm / "lib")]},
                              self.root / "pack", "test", 8192, self.root / "data", None)
        self.assertEqual(maya.read_json(p)["env"]["STRATA_HIPBLASLT_TUNING"], "/selected/table.txt")

    def test_rocm_devel_links_repaired(self):
        # #574: rocm-sdk init skipped the device-library links whose unnormalized target passed 260 characters
        site = self.root / "site"
        lib = site / "_rocm_sdk_libraries"
        (lib / "bin/rocblas/library/gfx1151").mkdir(parents=True)
        for f in ("Kernels.hsaco", "TensileLibrary_Type_x.dat"):
            (lib / "bin/rocblas/library/gfx1151" / f).write_bytes(f.encode())
        (lib / ".devel_links").mkdir()
        up = "../../../../../_rocm_sdk_libraries/bin/rocblas/library/gfx1151/"
        links = [{"relpath": f"bin/rocblas/library/gfx1151/{f}", "target": up + f}
                 for f in ("Kernels.hsaco", "TensileLibrary_Type_x.dat", "gone.dat")]
        (lib / ".devel_links/gfx1151.json").write_text(json.dumps({"version": "7.14.1", "links": links}))
        self.assertEqual(maya.rocm_devel_links(site), (0, []))           # (no expanded SDK yet: nothing to check)
        devel = site / "_rocm_sdk_devel/bin/rocblas/library/gfx1151"
        devel.mkdir(parents=True)
        os.link(lib / "bin/rocblas/library/gfx1151/Kernels.hsaco", devel / "Kernels.hsaco")   # the one init made
        self.assertEqual(maya.rocm_devel_links(site, repair=False),
                         (0, [links[1]["relpath"], links[2]["relpath"]]))
        made, absent = maya.rocm_devel_links(site)
        self.assertEqual((made, absent), (1, [links[2]["relpath"]]))   # a target that is not there stays absent
        self.assertEqual((devel / "TensileLibrary_Type_x.dat").read_bytes(), b"TensileLibrary_Type_x.dat")
        self.assertTrue((devel / "TensileLibrary_Type_x.dat").samefile(
            lib / "bin/rocblas/library/gfx1151/TensileLibrary_Type_x.dat"))   # a hard link, as init makes them
        self.assertEqual(maya.rocm_devel_links(site), (0, [links[2]["relpath"]]))

    def test_tuning_table_list_uses_the_os_path_separator(self):
        # Windows joins with ';': a ':' would also split the drive letter of C:\... (the engine then opened \...)
        tables = self.root / "tools/hip"
        tables.mkdir(parents=True)
        for v in ("100202", "100401"):
            (tables / f"gfx1100-glm-hipblaslt-{v}.txt").write_text(f"STRATA_HIPBLASLT_TUNING_V1 gfx1100 {v}\n")
        pc = maya.check_pc(self.a)
        for sep in (";", ":"):
            with self.subTest(sep=sep), patch.object(maya.os, "pathsep", sep):
                p = maya.write_config(self.a, pc, {"lib_dirs": [str(self.rocm / "lib")]},
                                      self.root / "pack", "test", 8192, self.root / "data", None)
                self.assertEqual(maya.read_json(p)["env"]["STRATA_HIPBLASLT_TUNING"],
                                 sep.join(str(tables / f"gfx1100-glm-hipblaslt-{v}.txt")
                                          for v in ("100202", "100401")))

    def test_gpus_with_an_apu_use_discrete_first_and_sequential_loading(self):
        self.gpus.append({"index": 3, "arch": "gfx1151", "vendor": "amd", "name": "Radeon 8060S", "vram_gb": 112})
        self.a.gpu = None
        for order in ("1,3", "3,1"):
            self.a.gpus = order
            pc = maya.check_pc(self.a)
            self.assertEqual(pc["gpus"], [self.gpus[1], self.gpus[3]])
            p = maya.write_config(self.a, pc, {}, self.root / "pack", "test", 8192, self.root / "data", None)
            cfg = maya.read_json(p)
            self.assertEqual(cfg["gpu"], [1, 3])
            self.assertEqual(cfg["env"]["STRATA_GLM_PARALLEL_LOAD"], "0")
            self.assertNotIn("STRATA_GLM_SPLIT", cfg["env"])
        self.a.gpus = None
        self.a.gpu = 3
        self.assertEqual(maya.check_pc(self.a)["gpus"], [self.gpus[3]])

    def test_strix_halo_defaults_use_system_ram_not_vram(self):
        self.gpus.append({"index": 3, "arch": "gfx1151", "vendor": "amd",
                          "name": "AMD Radeon (gfx1151)", "vram_gb": 0.5})
        self.a.gpu = 3
        tables = self.root / "tools/hip"
        tables.mkdir(parents=True)
        table = tables / "gfx1151-glm-hipblaslt-100202.txt"
        table.write_text("STRATA_HIPBLASLT_TUNING_V1 gfx1151 100202\n")
        pc = maya.check_pc(self.a)
        self.assertEqual(pc["gpus"], [self.gpus[3]])
        self.assertTrue(maya.hip_unified_memory(pc["gpus"][0]))
        for ram, budget in ((64, "4096"), (96, "6144"), (128, "6144")):
            with self.subTest(ram=ram), patch.object(maya, "mem_gb", return_value=(ram, ram - 8)):
                p = maya.write_config(self.a, pc, {}, self.root / "pack", "test", 8192,
                                      self.root / "data", None)
                env = maya.read_json(p)["env"]
                self.assertEqual(env["STRATA_GLM_SPLIT"], "0")
                self.assertEqual(env["STRATA_GLM_RESERVE_MB"], "1024")
                self.assertEqual(env["STRATA_GLM_RAM_HEADROOM_GB"], "16")
                self.assertEqual(env["STRATA_GLM_PREFILL_SUB"], "1024")
                self.assertEqual(env["STRATA_GLM_PREFILL_MB"], budget)
                self.assertEqual(env["STRATA_HIPBLASLT_TUNING"], str(table))
                self.assertNotIn("STRATA_GLM_POOL_GB", env)
                self.assertNotIn("STRATA_GLM_RAM_GB", env)
                self.assertNotIn("STRATA_GLM_PREFILL_CHUNK", env)

    def test_strix_halo_explicit_settings_win(self):
        self.gpus.append({"index": 3, "arch": "gfx1151", "vendor": "amd",
                          "name": "Radeon 8060S", "vram_gb": 112})
        self.a.gpu = 3
        explicit = {"STRATA_GLM_RESERVE_MB": "2048", "STRATA_GLM_RAM_HEADROOM_GB": "8",
                    "STRATA_GLM_POOL_GB": "84", "STRATA_GLM_RAM_GB": "4",
                    "STRATA_GLM_PREFILL_SUB": "512", "STRATA_GLM_PREFILL_MB": "3072",
                    "STRATA_HIPBLASLT_TUNING": "/custom/table.txt"}
        self.a.env = [f"{k}={v}" for k, v in explicit.items()]
        p = maya.write_config(self.a, maya.check_pc(self.a), {}, self.root / "pack", "test", 8192,
                              self.root / "data", None)
        env = maya.read_json(p)["env"]
        for k, v in explicit.items():
            self.assertEqual(env[k], v)

    def test_discrete_r9700_defaults_unchanged(self):
        self.a.gpu = 1
        p = maya.write_config(self.a, maya.check_pc(self.a), {}, self.root / "pack", "test", 8192,
                              self.root / "data", None)
        self.assertEqual(maya.read_json(p)["env"], {
            "STRATA_GLM_SPLIT": "0", "STRATA_GLM_RESERVE_MB": "3072", "STRATA_GLM_RAM_HEADROOM_GB": "16",
            "STRATA_GLM_PREFILL_SUB": "1024", "STRATA_GLM_PREFILL_MB": "4096"})
        self.assertFalse(maya.hip_unified_memory(self.gpus[1]))

    def test_hip_build_enables_mmq_and_never_cuda(self):
        pc = maya.check_pc(self.a)
        maya.BUILD.mkdir()
        with patch.object(maya, "pick_cmake", return_value="cmake"), \
                patch.object(maya, "cmake_steps", return_value=None) as build:
            meta = maya.compile_engine_hip(pc, self.root / "llama", "source-sha")
        conf, _, env, _ = build.call_args.args
        self.assertIn("-DSTRATA_ENABLE_HIP=ON", conf)
        self.assertIn("-DSTRATA_ENABLE_CUDA=OFF", conf)
        self.assertIn("-DSTRATA_PREFILL_MMQ=ON", conf)
        self.assertIn("-DCMAKE_HIP_ARCHITECTURES=gfx1100", conf)     # the chosen card's (#255)
        self.assertEqual(env["ROCM_PATH"], str(self.rocm))
        self.assertEqual(meta["backend"], "hip")

    def test_refresh_compiles_a_target_the_new_source_has_not_built(self):
        # #664: after a git pull, starting GLM compiled build-hip/maya and stamped the new source with targets
        # ["maya"]; the DeepSeek setup's next start found that source in the stamp and ran the old maya-ds4.
        build = self.root / "build-hip"
        build.mkdir()
        (self.root / "llama/ggml").mkdir(parents=True)
        (self.root / "llama/ggml/CMakeLists.txt").touch()
        stamp = {"backend": "hip", "src": "new-sha", "archs": ["gfx1151"], "rocm": str(self.rocm),
                 "llama": str(self.root / "llama"), "targets": ["maya"]}
        cfg = {"exe": str(build / "maya-ds4"), "backend": "hip", "gpu": [0]}
        with patch.object(maya, "EXE", build / "maya"), patch.object(maya, "DS4_EXE", build / "maya-ds4"), \
                patch.object(maya, "MM3_EXE", build / "maya-mm3"), \
                patch.object(maya, "STAMP", build / "MAYA-BUILD.json"), \
                patch.object(maya.S, "source_hash", return_value="new-sha"), \
                patch.object(maya, "hip_clang", return_value=self.rocm / "llvm/bin/clang++"), \
                patch.object(maya, "compile_engine_hip") as compile_hip:
            maya.STAMP.write_text(json.dumps(stamp))
            maya.refresh_engine(cfg)
            compile_hip.assert_called_once()
            self.assertEqual(compile_hip.call_args.kwargs["target"], "maya-ds4")
            compile_hip.reset_mock()
            stamp["targets"] = ["maya", "maya-ds4"]
            maya.STAMP.write_text(json.dumps(stamp))
            maya.refresh_engine(cfg)                    # compiled from this source already: nothing to do
            compile_hip.assert_not_called()

    def test_failed_update_build_never_starts_the_engine_from_before(self):
        # #805: "HIP rebuild failed; starting the previous engine" ran the old exe under the new server and config
        pc = {"rocm": str(self.rocm), "archs": ["gfx1151"], "gpus": [{"index": 0}]}
        with patch.object(maya, "pick_cmake", return_value="cmake"), patch.object(maya, "WIN", False), \
                patch.object(maya, "hip_toolchain", return_value=(self.rocm, self.rocm / "llvm/bin/clang++",
                                                                  self.rocm / "bin", {})), \
                patch.object(maya, "cmake_steps", return_value="compiling"), \
                patch.object(maya, "fail", side_effect=SystemExit(1)) as stop:
            with self.assertRaises(SystemExit):
                maya.compile_engine_hip(pc, self.root / "llama", "source-sha", soft=True)
        self.assertIn("not started", stop.call_args.args[0])

    def test_refresh_without_the_hip_compiler_stops(self):
        build = self.root / "build-hip"
        build.mkdir()
        stamp = {"backend": "hip", "src": "old-sha", "archs": ["gfx1151"], "rocm": str(self.root / "gone"),
                 "llama": str(self.root / "llama"), "targets": ["maya-ds4"]}
        cfg = {"exe": str(build / "maya-ds4"), "backend": "hip", "gpu": [0]}
        with patch.object(maya, "EXE", build / "maya"), patch.object(maya, "DS4_EXE", build / "maya-ds4"), \
                patch.object(maya, "MM3_EXE", build / "maya-mm3"), \
                patch.object(maya, "STAMP", build / "MAYA-BUILD.json"), \
                patch.object(maya.S, "source_hash", return_value="new-sha"), \
                patch.object(maya, "hip_clang", return_value=None), \
                patch.object(maya, "fail", side_effect=SystemExit(1)) as stop:
            maya.STAMP.write_text(json.dumps(stamp))
            with self.assertRaises(SystemExit):
                maya.refresh_engine(cfg)
        self.assertIn("--setup --rebuild", stop.call_args.args[1])

    def test_hip_no_vision_skips_without_downloading(self):
        self.a.no_vision = True
        with patch.object(maya.S, "download", side_effect=AssertionError("no vision downloads")):
            self.assertIsNone(maya.vision_step(self.a, {"backend": "hip"}, {}, self.root, self.root, "test"))

    def test_hip_builds_the_vision_encoder(self):
        # (#345) a HIP setup compiles maya-vision for its own GPUs, as a CUDA one does: the encoder on demand
        spec = maya.MODELS.get("test") or maya.MODELS[next(iter(maya.MODELS))]
        m = spec["vision"]
        (self.root / m["folder"]).mkdir(parents=True, exist_ok=True)
        for k in ("mmproj", "vocab"):
            (self.root / m["folder"] / m[k]).write_bytes(b"x")
        pc = {"backend": "hip", "archs": ["gfx1151"]}
        self.a.rebuild = False
        with patch.object(maya.S, "download", side_effect=AssertionError("no vision downloads")), \
                patch.object(maya, "compile_vision", return_value=True) as compile_vision, \
                patch.object(maya, "VEXE", self.root / "no-maya-vision"):
            v = maya.vision_step(self.a, pc, {"archs": ["gfx1151"]}, self.root, self.root, "test")
        compile_vision.assert_called_once()
        self.assertIs(compile_vision.call_args[0][0], pc)
        self.assertTrue(v["gpu"])

    def installed_config(self, backend="hip", gpu=None):
        tp = self.root / "tokenizer"
        tp.mkdir(exist_ok=True)
        (tp / "vocab.json").write_text('{"hello": 0}')
        (tp / "merges.txt").write_text("")
        (tp / "token_type.json").write_text("[1]")
        # A stale CUDA executable in a HIP config must not select the CUDA build.
        cfg = {"exe": str(self.root / "build/maya"), "args": ["--max-context", "16384"],
               "tokenizer": str(tp), "gpu": [0] if gpu is None else gpu,
               "env": {"STRATA_GLM_PREFILL_SUB": "512", "STRATA_GLM_RAM_GB": "60"},
               "lib_dirs": [str(self.rocm / "lib")]}
        if backend == "hip":
            cfg["backend"] = backend
        path = self.root / f"maya-test-{backend}.json"
        path.write_text(json.dumps(cfg))
        return path

    def run_bench(self, path):
        proc = MagicMock()
        proc.stdout.readline.side_effect = ["READY\n"] + ["DONE 256 0 1000 2000\n"] * 7
        tok = MagicMock()
        tok.encode.return_value = list(range(9000))
        # Exercise the real server's engine_args/child_env without optional tokenizer/template packages.
        modules = {"strata_tokenizer": SimpleNamespace(Tokenizer=SimpleNamespace(from_dir=MagicMock(return_value=tok))),
                   "serve.frontend": MagicMock()}
        with patch("urllib.request.urlopen", side_effect=OSError("no server")), \
                patch.dict(sys.modules, modules), \
                patch.object(maya.S, "out", side_effect=AssertionError("bench must not run GPU queries")), \
                patch.object(maya.subprocess, "Popen", return_value=proc) as popen, \
                patch.dict(os.environ, {}, clear=True):
            self.assertEqual(maya.bench(path, "test"), 0)
        proc.wait.assert_called_once_with(timeout=120)
        self.assertIn("QUIT\n", [call.args[0] for call in proc.stdin.write.call_args_list])
        text = (self.root / "maya-bench.txt").read_text()
        self.assertIn("128.0 tokens/s over 3 answers", text)
        self.assertIn("2048 tokens/s, 2048 tokens", text)
        self.assertIn("8192 tokens/s, 8192 tokens", text)
        return popen.call_args, text

    def test_bench_uses_hip_build_and_config_env(self):
        call, text = self.run_bench(self.installed_config(gpu=[1, 0]))
        self.assertEqual(maya.BUILD, self.root / "build-hip")
        self.assertEqual(maya.STAMP, self.root / "build-hip/MAYA-BUILD.json")
        self.assertEqual(call.args[0][:2], [str(self.root / "build-hip/maya"), "--serve"])
        self.assertEqual(call.args[0][-2:], ["--layer-split", "auto"])
        env = call.kwargs["env"]
        self.assertEqual(env["HIP_VISIBLE_DEVICES"], "1,0")
        self.assertNotIn("CUDA_VISIBLE_DEVICES", env)
        self.assertNotIn("CUDA_DEVICE_ORDER", env)
        self.assertEqual(env["STRATA_GLM_PREFILL_SUB"], "512")
        self.assertEqual(env["STRATA_GLM_RAM_GB"], "60")
        self.assertEqual(env["LD_LIBRARY_PATH"], str(self.rocm / "lib"))
        self.assertIn("GPUs: R9700 32 GB, RX 7900 XT 20 GB", text)
        self.assertIn("GPUs [1, 0]", text)

    def test_bench_cuda_command_and_env_unchanged(self):
        path = self.installed_config(backend="cuda", gpu=[1, 0])
        cfg = maya.read_json(path)
        cfg["exe"] = str(self.root / "custom-cuda/strata")
        path.write_text(json.dumps(cfg))
        with patch.object(maya.S, "gpus", return_value=[{"name": "V100", "vram_gb": 16}]), \
                patch.object(maya.S, "amd_gpus", side_effect=AssertionError("CUDA must not query AMD")):
            call, text = self.run_bench(path)
        self.assertEqual(call.args[0][:2], [cfg["exe"], "--serve"])
        self.assertEqual(maya.BUILD, self.root / "build")
        self.assertEqual(call.kwargs["env"]["CUDA_VISIBLE_DEVICES"], "1,0")
        self.assertEqual(call.kwargs["env"]["CUDA_DEVICE_ORDER"], "PCI_BUS_ID")
        self.assertNotIn("HIP_VISIBLE_DEVICES", call.kwargs["env"])
        self.assertIn("GPUs: V100 16 GB", text)

    def test_bench_single_hip_gpu(self):
        call, text = self.run_bench(self.installed_config(gpu=0))
        self.assertEqual(call.kwargs["env"]["HIP_VISIBLE_DEVICES"], "0")
        self.assertNotIn("--layer-split", call.args[0])
        self.assertIn("GPUs: RX 7900 XT 20 GB;", text)

    def test_bench_uses_ds4_build_on_hip(self):
        # #350: bench() hardcoded the GLM binary for every HIP config, so a DeepSeek setup's --bench crashed with
        # FileNotFoundError (build-hip/maya was never built there - build-hip/maya-ds4 was).
        path = self.installed_config(gpu=[1, 0])
        cfg = maya.read_json(path)
        cfg["exe"] = str(self.root / "build-hip/maya-ds4")            # what write_config_ds4 actually writes
        cfg["args"] = ["--pack", str(self.root / "model/maya-ds4")] + cfg["args"]
        path.write_text(json.dumps(cfg))
        call, _ = self.run_bench(path)
        self.assertEqual(call.args[0][:2], [str(self.root / "build-hip/maya-ds4"), "--serve"])

    def run_report(self, outputs=None, tools=(), backend=None, cfg_path=None):
        outputs = outputs or {}

        def out(cmd):
            self.assertNotEqual(Path(cmd[0]).name, "nvidia-smi", "HIP report must not query NVIDIA")
            return outputs.get(Path(cmd[0]).name, "")

        with patch.object(maya.S, "out", side_effect=out) as query, \
                patch.object(maya.S, "page_file_gb", return_value=None), \
                patch.object(maya.shutil, "which", side_effect=lambda name: f"/usr/bin/{name}" if name in tools else None):
            self.assertEqual(maya.report("test", backend, cfg_path), 0)
        return (self.root / "maya-report.txt").read_text(), query

    def test_report_rocm_smi_json_and_engine_speed_lines(self):
        cfg_path = self.installed_config()
        log = cfg_path.with_suffix(".log")
        speed = ["glm fast: CUDA0 expert pool 12 GB", "glm prefill: CUDA0 chunks of 1024 tokens",
                 "glm prefill: HIP0 chunks of 1024 tokens", "glm prefill: 2048 tokens at 413 tok/s",
                 "glm stat: decode 50.0 ms/tok | prompt 400 tok/s",
                 "glm stat: decode 0.1 ms/tok vram hit 0.00% | prompt 413 tok/s"]
        log.write_text("\n".join(speed) + "\n")
        (self.root / "build-hip").mkdir()
        (self.root / "build-hip/MAYA-BUILD.json").write_text(json.dumps({
            "backend": "hip", "archs": ["gfx1100", "gfx1201"], "rocm": str(self.rocm), "date": "test-date"}))
        (self.rocm / ".info").mkdir()
        (self.rocm / ".info/version").write_text("7.2.1\n")
        # SMI names differ from KFD: keep both sources without assuming their device order matches.
        smi = {"card0": {"Card series": "AMD Radeon RX 7900 XT", "VRAM Total Memory (B)": str(20 * 2**30)},
               "card1": {"Card series": "AMD Radeon AI PRO R9700", "VRAM Total Memory (B)": str(32 * 2**30)},
               "system": {"Driver version": "6.14.0-37"}}
        text, query = self.run_report({"rocm-smi": json.dumps(smi)}, tools=("rocm-smi",))
        self.assertIn("GPU 0 (RX 7900 XT, 20 GB, gfx1100)", text)
        self.assertIn("GPU 1 (R9700, 32 GB, gfx1201)", text)
        self.assertIn("AMD Radeon RX 7900 XT", text)
        self.assertIn("AMD Radeon AI PRO R9700", text)
        self.assertIn(str(32 * 2**30), text)
        self.assertIn("6.14.0-37", text)
        shown = str(self.rocm).replace(str(Path.home()), "~")
        self.assertIn(f"path {shown}\nversion 7.2.1", text)
        self.assertIn('"backend": "hip"', text)
        self.assertIn("test-date", text)
        self.assertIn("the speed and memory lines (last 80 of 6)", text)
        for line in maya.speed_lines(speed):
            self.assertIn(line, text)
        query.assert_any_call(["/usr/bin/rocm-smi", "--showproductname", "--showmeminfo", "vram",
                               "--showdriverversion", "--json"])

    def test_report_carries_minimax_engine_lines(self):
        # a MiniMax report had none of its engine's lines ("last 80 of 0"): maya-mm3 --serve wrote where the model went
        # to the server only, and REPORT_LINES knew no maya-mm3 line
        kept = ["maya-mm3: loaded in 171.2 s, 9216 of 9216 experts in VRAM, 0.0 GB pinned pool",
                "maya-mm3: weights: GGUF MiniMax-M3.1-Flash-Maya-S (dense Q6_K)",
                "maya-mm3: VRAM 0 dense 7.9 GB, experts 118.1 GB",
                "maya mm3 serve: DSpark kept 189 of 245 drafts",
                "maya mm3 serve: prompt 201 tokens = 172 reused + 29 read in 806 ms (36.0 tok/s), 256 generated in "
                "13334 ms (19.20 tok/s); CPU lane 0.0% of the experts"]
        other = ["maya mm3 serve: GEN <max_new> [keys] <ids>; GENI <max_new> [keys] <file> <ids>; STOP, QUIT"]
        self.assertEqual(maya.speed_lines(kept + other), kept)

    def test_report_minimax_images_from_its_vision_arg(self):
        # a MiniMax report said "images off" with --vision on: it read cfg["vision"], which only GLM's configs set
        path = self.installed_config()
        cfg = maya.read_json(path)
        cfg["exe"] = str(self.root / "build-hip/maya-mm3")
        for args, shown in ((["--vision", "on"], "images on"), (["--vision", "off"], "images off"), ([], "images off")):
            with self.subTest(args=args):
                cfg["args"] = ["--pack", str(self.root / "model/maya-mm3"), "--max-context", "65536"] + args
                path.write_text(json.dumps(cfg))
                text, _ = self.run_report(cfg_path=path)
                self.assertIn(shown + ",", text)

    def test_report_kfd_fallback_without_smi_or_rocm_version(self):
        self.installed_config()
        text, query = self.run_report()
        self.assertIn("GPU 0 (RX 7900 XT, 20 GB, gfx1100)", text)
        self.assertIn("GPU 1 (R9700, 32 GB, gfx1201)", text)
        self.assertIn("amdgpu driver:", text)
        self.assertIn("kernel", text)
        self.assertIn("using KFD topology", text)
        self.assertIn("path " + str(self.rocm).replace(str(Path.home()), "~"), text)
        self.assertIn("version unknown", text)
        self.assertFalse(any(Path(c.args[0][0]).name in ("rocm-smi", "amd-smi", "hipcc")
                             for c in query.call_args_list))

    def test_report_rocm_path_inside_and_outside_home(self):
        self.installed_config()
        for home, shown in ((self.root, str(Path("~") / "rocm")), (self.root / "other-home", str(self.rocm))):
            with self.subTest(home=home), patch.object(Path, "home", return_value=home):
                text, _ = self.run_report()
                self.assertIn(f"path {shown}\n", text)
                if home == self.root:
                    self.assertNotIn(str(home), text)

    def test_report_amd_smi_after_bad_rocm_smi_json(self):
        self.installed_config()
        smi = [{"gpu": 0, "asic": {"market_name": "AMD Radeon RX 7900 XT", "target_graphics_version": "gfx1100"},
                "vram": {"size": "20480 MB"}, "driver": {"driver_version": "6.14.0", "rocm_version": "7.2.1"}}]
        text, query = self.run_report({"rocm-smi": "not JSON", "amd-smi": json.dumps(smi)},
                                      tools=("rocm-smi", "amd-smi"))
        self.assertIn("amd-smi (tool GPU indices)", text)
        self.assertIn("AMD Radeon RX 7900 XT", text)
        self.assertIn("20480 MB", text)
        self.assertIn("6.14.0", text)
        self.assertIn("7.2.1", text)
        query.assert_any_call(["/usr/bin/amd-smi", "static", "--json"])

    def test_report_kfd_fallback_for_empty_or_invalid_smi_json(self):
        self.installed_config()
        for response in ("", "warning: no access", "{}", "[]", "null", '"error"'):
            with self.subTest(response=response):
                text, _ = self.run_report({"rocm-smi": response, "amd-smi": response},
                                          tools=("rocm-smi", "amd-smi"))
                self.assertIn("GPU 1 (R9700, 32 GB, gfx1201)", text)
                self.assertIn("using KFD topology", text)

    def test_report_finds_smi_in_rocm_bin_and_hipcc_version(self):
        self.installed_config()
        (self.rocm / "bin").mkdir()
        (self.rocm / "bin/rocm-smi").touch()
        (self.rocm / "bin/hipcc").touch()
        text, query = self.run_report({"rocm-smi": '{"system": {"Driver version": "6.14.0"}}',
                                       "hipcc": "HIP version: 7.2.1"})
        self.assertIn("rocm-smi (tool GPU indices)", text)
        self.assertIn("version HIP version: 7.2.1", text)
        query.assert_any_call([str(self.rocm / "bin/hipcc"), "--version"])

    def test_report_hip_without_config_or_gpus(self):
        with patch.object(maya.S, "amd_gpus", return_value=[]):
            text, _ = self.run_report(backend="hip")
        self.assertIn("no AMD GPUs found in KFD topology", text)
        self.assertIn("## ROCm", text)
        self.assertIn("not compiled yet", text)

    def test_report_explicit_config_selects_hip_env_and_log(self):
        self.installed_config(backend="cuda")
        path = self.installed_config().rename(self.root / "chosen.json")
        cfg = maya.read_json(path)
        root = self.root / "chosen-rocm"
        (root / ".info").mkdir(parents=True)
        (root / ".info/version").write_text("7.2.2\n")
        cfg["env"]["ROCM_PATH"] = str(root)
        path.write_text(json.dumps(cfg))
        path.with_suffix(".log").write_text("glm stat: decode 50.0 ms/tok | prompt 413 tok/s\n")
        text, _ = self.run_report(cfg_path=path)
        shown = str(root).replace(str(Path.home()), "~")
        self.assertIn(f"path {shown}\nversion 7.2.2", text)
        self.assertIn("Setup chosen.json", text)
        self.assertIn("Engine log chosen.log: the speed and memory lines", text)
        self.assertNotIn("Setup maya-test-cuda.json", text)

    def test_report_cuda_query_and_stamp_unchanged(self):
        self.installed_config(backend="cuda")
        (self.root / "build").mkdir()
        stamp = {"archs": [70], "nvcc": "/usr/local/cuda/bin/nvcc", "host_compiler": "g++-12", "date": "test-date"}
        (self.root / "build/MAYA-BUILD.json").write_text(json.dumps(stamp))
        with patch.object(maya.S, "out", return_value="NVIDIA V100") as query, \
                patch.object(maya.S, "page_file_gb", return_value=None), \
                patch.object(maya.S, "amd_gpus", side_effect=AssertionError("CUDA must not query AMD")):
            self.assertEqual(maya.report("test"), 0)
        query.assert_any_call(["nvidia-smi", "--query-gpu=index,name,memory.total,memory.used,driver_version,"
                                             "pcie.link.gen.max,pcie.link.width.current,pcie.link.width.max,power.limit,"
                                             "temperature.gpu", "--format=csv"])
        text = (self.root / "maya-report.txt").read_text()
        self.assertIn(json.dumps(stamp), text)
        self.assertNotIn("## ROCm", text)

    def test_cli_backend_selects_hip_config_for_bench(self):
        hip = self.installed_config()
        cuda = self.installed_config(backend="cuda")
        with patch.object(maya, "configs", return_value=[cuda, hip]), \
                patch.object(sys, "argv", ["maya.py", "--backend", "hip", "--bench"]), \
                patch.object(maya, "bench", return_value=0) as bench:
            self.assertEqual(maya.main(), 0)
        bench.assert_called_once_with(hip, (maya.HERE / "VERSION").read_text().strip())

    def test_cli_explicit_config_for_bench_and_report(self):
        path = self.installed_config()
        for action in ("bench", "report"):
            with self.subTest(action=action), \
                    patch.object(sys, "argv", ["maya.py", "--backend", "hip", f"--{action}", "--config", str(path)]), \
                    patch.object(maya, action, return_value=0) as run:
                self.assertEqual(maya.main(), 0)
                self.assertIn(path, run.call_args.args)

    def test_cli_backend_never_benchmarks_cuda_config_as_hip(self):
        self.installed_config(backend="cuda")
        with patch.object(sys, "argv", ["maya.py", "--backend", "hip", "--bench"]), \
                patch.object(maya, "bench", side_effect=AssertionError("must not start the CUDA engine")):
            with self.assertRaises(SystemExit):
                maya.main()

    def first_run_backend(self, nvidia, amd):
        with patch.object(maya, "configs", return_value=[]), \
                patch.dict(os.environ, MAYA_SH="1"), \
                patch.object(sys, "argv", ["maya.py", "--check"]), \
                patch.object(maya.S, "gpus", return_value=nvidia), \
                patch.object(maya.S, "amd_gpus", return_value=amd), \
             patch.object(maya, "apple_silicon", return_value=False), \
                patch.object(maya, "check_pc", return_value={"gpus": [{"index": 0}]}) as check:
            self.assertEqual(maya.main(), 0)
        return check.call_args.args[0].backend

    def test_first_run_without_backend_picks_hip_on_an_amd_only_pc(self):
        strix = {"index": 0, "arch": "gfx1151", "vendor": "amd", "name": "Radeon 8060S", "vram_gb": 96}
        self.assertEqual(self.first_run_backend([], [strix]), "hip")
        self.assertEqual(self.first_run_backend([], [self.gpus[2]]), "cuda")   # (unsupported iGPU: CUDA's message)
        self.assertEqual(self.first_run_backend([{"index": 0, "arch": "70"}], [strix]), "cuda")

    def test_first_run_without_backend_takes_every_arch_the_hip_check_takes(self):
        # (#805) the experimental ones too: the CUDA checks would stop at nvidia-smi
        for arch in maya.HIP_ARCHS_UNVALIDATED + maya.HIP_ARCHS_WAVE64:
            card = {"index": 0, "arch": arch, "vendor": "amd", "name": arch, "vram_gb": 16}
            self.assertEqual(self.first_run_backend([], [card]), "hip", arch)

    def test_first_run_on_windows_names_the_amd_gpus_with_an_installed_hipinfo(self):
        r9700 = {"index": 0, "arch": "gfx1201", "vendor": "amd", "name": "R9700", "vram_gb": 32}
        with patch.object(maya, "WIN", True), patch.object(maya, "apple_silicon", return_value=False), \
                patch.object(maya.S, "gpus", return_value=[]), \
                patch.object(maya, "installed_hip_info", return_value=r"C:\rocm\bin\hipInfo.exe"), \
                patch.object(maya.S, "amd_gpus", return_value=[r9700]) as amd:
            self.assertEqual(maya.first_run_backend(), "hip")
        amd.assert_called_once_with(r"C:\rocm\bin\hipInfo.exe")

    def test_installed_hipinfo_is_the_newest_rocm_in_program_files(self):
        with tempfile.TemporaryDirectory() as d:
            for ver in ("6.4", "7.2", "7.10"):
                (Path(d) / "AMD/ROCm" / ver / "bin").mkdir(parents=True)
            (Path(d) / "AMD/ROCm/6.4/bin/hipInfo.exe").touch()
            (Path(d) / "AMD/ROCm/7.2/bin/hipInfo.exe").touch()
            env = {k: v for k, v in os.environ.items() if k not in ("ROCM_PATH", "HIP_PATH")}
            with patch.dict(os.environ, dict(env, ProgramFiles=d), clear=True), \
                    patch.object(maya.shutil, "which", return_value=None):
                self.assertEqual(maya.installed_hip_info(), str(Path(d) / "AMD/ROCm/7.2/bin/hipInfo.exe"))


class ConfigsTests(unittest.TestCase):
    def test_dashboard_settings_beside_a_config_are_not_a_config(self):
        with tempfile.TemporaryDirectory() as d, patch.object(maya, "ROOT", Path(d)):
            cfg = Path(d) / "maya-maya-l-hip.json"
            cfg.write_text(json.dumps({"backend": "hip", "exe": "maya.exe"}))
            side = Path(d) / "maya-maya-l-hip.shared-settings.json"
            side.write_text(json.dumps({"temperature": 0.7}))
            os.utime(cfg, (1, 1))   # the settings file is the newer one, as after a dashboard change
            self.assertEqual(maya.configs(), [cfg])


HIPINFO = """
--------------------------------------------------------------------------------
device#                           0
Name:                             AMD Radeon(TM) 8065S Graphics
pciBusID:                         195
totalGlobalMem:                   96.00 GB
gcnArchName:                      gfx1151
isIntegrated:                     1
--------------------------------------------------------------------------------
device#                           1
Name:                             AMD Radeon RX 7900 XTX
totalGlobalMem:                   23.98 GB
gcnArchName:                      gfx1100:sramecc-:xnack-
isIntegrated:                     0
"""


class WindowsDetectionTests(unittest.TestCase):
    def test_hipinfo_lists_gpus_in_hip_order(self):
        gpus = maya.S.parse_hipinfo(HIPINFO)
        self.assertEqual([(g["index"], g["arch"]) for g in gpus], [(0, "gfx1151"), (1, "gfx1100")])
        self.assertEqual(gpus[0]["name"], "AMD Radeon(TM) 8065S Graphics")
        self.assertAlmostEqual(gpus[0]["vram_gb"], 96.0)
        self.assertTrue(gpus[0]["integrated"])
        self.assertFalse(gpus[1]["integrated"])
        self.assertEqual(maya.S.parse_hipinfo("hipInfo: no devices\n"), [])

    def test_registry_adapters_by_device_id_then_name(self):
        one = json.dumps({"DriverDesc": "AMD Radeon(TM) 8060S Graphics",
                          "MatchingDeviceId": "pci\\ven_1002&dev_1586&rev_c1", "DriverVersion": "32.0.21",
                          "HardwareInformation.qwMemorySize": 96 * 2**30})
        g, = maya.S.parse_display_adapters(one)            # one adapter: an object, not a list
        self.assertEqual((g["index"], g["arch"], g["driver"]), (0, "gfx1151", "32.0.21"))
        self.assertAlmostEqual(g["vram_gb"], 96.0)
        rows = json.dumps([{"DriverDesc": "AMD Radeon(TM) 8065S Graphics", "MatchingDeviceId": "pci\\ven_1002&dev_9999"},
                           {"DriverDesc": "AMD Radeon RX 9070 XT", "MatchingDeviceId": "pci\\ven_1002&dev_7550"},
                           {"DriverDesc": "AMD Radeon(TM) Graphics", "MatchingDeviceId": "pci\\ven_1002&dev_164e"}])
        self.assertEqual([g["arch"] for g in maya.S.parse_display_adapters(rows)], ["gfx1151", "gfx1201", "unknown"])
        self.assertEqual(maya.S.parse_display_adapters(""), [])
        self.assertEqual(maya.S.parse_display_adapters("not json"), [])

    def test_windows_apu_names_are_unified_memory(self):
        for name in ("AMD Radeon(TM) 8060S Graphics", "AMD Radeon(TM) 8065S Graphics", "Radeon 8050S"):
            self.assertTrue(maya.hip_unified_memory({"arch": "unknown", "name": name}), name)
        self.assertFalse(maya.hip_unified_memory({"arch": "gfx1100", "name": "AMD Radeon RX 7900 XTX"}))


ROCM_DEVICES_MISSING, FIND_VCVARS = maya.rocm_devices_missing, maya.S.find_vcvars   # (setUp replaces them)


class WindowsHipSetupTests(unittest.TestCase):
    """START-MAYA.bat --backend hip on a Strix Halo / Gorgon Halo PC, with TheRock's ROCm wheels."""

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.rocm = self.root / "_rocm_sdk_devel"        # TheRock's layout
        (self.rocm / "lib/llvm/bin").mkdir(parents=True)
        (self.rocm / "lib/llvm/bin/clang++.exe").touch()
        (self.rocm / "lib/llvm/bin/clang.exe").touch()
        (self.rocm / "lib/hipblas.lib").touch()
        (self.rocm / "bin").mkdir()
        (self.rocm / "bin/hipblas.dll").touch()
        self.apu = {"index": 0, "arch": "gfx1151", "vendor": "amd", "name": "AMD Radeon(TM) 8065S Graphics",
                    "vram_gb": 96, "driver": "windows"}
        for ctx in (
            patch.object(maya, "ROOT", self.root),
            patch.object(maya, "BUILD", self.root / "build"),
            patch.object(maya, "EXE", self.root / "build/maya.exe"),
            patch.object(maya, "STAMP", self.root / "build/MAYA-BUILD.json"),
            patch.object(maya, "WIN", True),
            patch.object(maya.S, "amd_gpus", return_value=[self.apu]),
            patch.object(maya.S, "gpus", side_effect=AssertionError("HIP must not query NVIDIA")),
            patch.object(maya.S, "find_vcvars", return_value=Path("C:/VS/vcvars64.bat")),
            patch.object(maya.S, "cpu_info", return_value=("AMD RYZEN AI MAX+ PRO 495", True, True)),
            patch.object(maya, "mem_gb", return_value=(32, 24)),
            patch.object(maya, "tool_version", return_value=(7, 14)),
            patch.object(maya, "rocm_devices_missing", return_value=[]),
        ):
            ctx.start()
            self.addCleanup(ctx.stop)
        self.a = SimpleNamespace(backend="hip", gpu=None, gpus=None, no_vision=False, env=[], check=False, yes=True,
                                 port=8099, host=None, api_key=None, gguf_dir=None)

    def test_visual_studio_is_checked_before_the_rocm_download(self):
        with patch.object(maya.S, "find_vcvars", return_value=None), \
                patch.object(maya, "windows_rocm", side_effect=AssertionError("no ROCm lookup without VS")), \
                patch.object(maya, "run", side_effect=AssertionError("no pip without VS")):
            with self.assertRaises(SystemExit):
                maya.check_pc(self.a)

    def test_visual_studio_2026_is_taken_for_hip_and_for_a_cuda_13_2_toolkit(self):
        pf = self.root / "pf86"
        (pf / "Microsoft Visual Studio/Installer").mkdir(parents=True)
        (pf / "Microsoft Visual Studio/Installer/vswhere.exe").touch()
        vs = self.root / "VS2026"
        (vs / "VC/Auxiliary/Build").mkdir(parents=True)
        (vs / "VC/Auxiliary/Build/vcvars64.bat").touch()
        nvcc = self.root / "cuda13.4/bin/nvcc.exe"       # NVIDIA's install guide: 13.2+ takes VS 2026 (MSVC 195x)
        nvcc.parent.mkdir(parents=True)
        nvcc.touch()
        nvcc12 = self.root / "cuda12.8/bin/nvcc.exe"     # 12.x and CUDA <= 13.1 stop at VS 2022 (MSVC 193x)
        nvcc12.parent.mkdir(parents=True)
        nvcc12.touch()
        releases = {str(nvcc): "Cuda compilation tools, release 13.4, V13.4.159\n",
                    str(nvcc12): "Cuda compilation tools, release 12.8, V12.8.93\n"}

        def only_2026(cmd):        # nvcc --version answers; vswhere finds VS 2026 only, never the 2019/2022 range
            if cmd[1:] == ["--version"]:
                return releases.get(cmd[0], "")
            return "" if "[16.0,18.0)" in cmd else str(vs)
        with patch.dict(os.environ, {"ProgramFiles(x86)": str(pf)}), patch.object(maya.S, "out", side_effect=only_2026):
            self.assertIsNone(FIND_VCVARS())                         # CUDA, no toolkit given: 2019/2022 only
            self.assertIsNone(FIND_VCVARS(nvcc=str(nvcc12)))          # CUDA 12.8: its release stops at VS 2022
            self.assertEqual(FIND_VCVARS(nvcc=str(nvcc)), vs / "VC/Auxiliary/Build/vcvars64.bat")
            self.assertEqual(FIND_VCVARS(cuda=False), vs / "VC/Auxiliary/Build/vcvars64.bat")

    def test_rocm_sdk_init_runs_before_any_path_query(self):
        sdk = str(self.root / "venv/Scripts/rocm-sdk.exe")
        calls = []

        def out(cmd):
            calls.append(("out", cmd[1:]))
            return {"--root": f"{self.rocm}\n", "--bin": f"{self.rocm / 'bin'}\n"}.get(cmd[-1], "")
        env = {k: v for k, v in os.environ.items() if k != "ROCM_PATH"}
        with patch.dict(os.environ, env, clear=True), patch.object(maya, "rocm_sdk", return_value=sdk), \
                patch.object(maya, "run", side_effect=lambda cmd, **kw: calls.append(("run", cmd[1:]))), \
                patch.object(maya.S, "out", side_effect=out):
            self.assertEqual(maya.windows_rocm(), (self.rocm, self.rocm / "bin"))
        self.assertEqual(calls[0], ("run", ["init"]))                # unpacks, seen and with no time limit
        self.assertEqual([c[1] for c in calls[1:]], [["path", "--root"], ["path", "--bin"]])

    def test_missing_device_wheel_is_offered(self):
        with patch.object(maya, "windows_rocm", return_value=(self.rocm, self.rocm / "bin")), \
                patch.object(maya, "rocm_devices_missing", side_effect=[["gfx1151"], []]), \
                patch.object(maya, "run") as pip, patch.object(sys, "base_prefix", "/somewhere/else"):
            pc = maya.check_pc(self.a)
        self.assertIn(f"rocm[libraries,devel,device-gfx1151]=={maya.THEROCK_VERSION}", pip.call_args.args[0])
        self.assertEqual(pc["gpus"], [self.apu])
        self.a.check = True                                       # --check installs nothing: it says so
        with patch.object(maya, "windows_rocm", return_value=(self.rocm, self.rocm / "bin")), \
                patch.object(maya, "rocm_devices_missing", return_value=["gfx1151"]), \
                patch.object(maya, "run", side_effect=AssertionError("--check installs nothing")), \
                patch.object(maya, "warn") as warned:
            maya.check_pc(self.a)
        self.assertTrue(any("no library kernels for gfx1151" in c.args[0] for c in warned.call_args_list))

    def test_device_wheels_are_looked_up_only_in_mayas_venv(self):
        sdk = str(self.root / "venv/Scripts/rocm-sdk.exe")
        Path(sdk).parent.mkdir(parents=True)
        Path(sdk).touch()
        from importlib import metadata

        def version(name):
            if name == "rocm-sdk-device-gfx1151":
                raise metadata.PackageNotFoundError(name)
            return maya.THEROCK_VERSION
        env = {k: v for k, v in os.environ.items() if k not in ("ROCM_PATH", "ROCM_VENV")}
        real = ROCM_DEVICES_MISSING
        with patch.dict(os.environ, env, clear=True), patch.object(maya, "venv_tool", return_value=sdk), \
                patch("importlib.metadata.version", side_effect=version):
            self.assertEqual(real(["gfx1151", "gfx1100", "gfx1151"]), ["gfx1151"])
            with patch.dict(os.environ, {"ROCM_PATH": str(self.rocm)}):
                self.assertEqual(real(["gfx1151"]), [])             # another ROCm: not this Python's to check
            with patch.dict(os.environ, {"ROCM_VENV": str(self.root / "other")}), \
                    patch.object(maya.shutil, "which", return_value=None):
                (self.root / "other/Scripts").mkdir(parents=True)
                (self.root / "other/Scripts/rocm-sdk.exe").touch()
                self.assertEqual(real(["gfx1151"]), [])

    def test_hipinfo_that_sees_no_gpu_warns_before_the_download(self):
        with patch.dict(os.environ, {"ROCM_PATH": str(self.rocm)}), \
                patch.object(maya, "hip_info", return_value=str(self.rocm / "bin/hipInfo.exe")), \
                patch.object(maya.S, "amd_gpus", return_value=[dict(self.apu, source="registry")]), \
                patch.object(maya, "warn") as warned:
            maya.check_pc(self.a)
        self.assertTrue(any("hipInfo sees no AMD GPU" in c.args[0] for c in warned.call_args_list))

    def test_check_finds_therock_and_the_apu(self):
        with patch.dict(os.environ, {"ROCM_PATH": str(self.rocm)}):
            pc = maya.check_pc(self.a)
        self.assertEqual(pc["gpus"], [self.apu])
        self.assertEqual(pc["rocm"], str(self.rocm.resolve()))
        self.assertEqual(pc["rocm_bin"], str(self.rocm.resolve() / "bin"))
        self.assertEqual(maya.EXE, self.root / "build-hip/maya.exe")

    def test_check_without_rocm_says_the_pip_command(self):
        with patch.object(maya, "windows_rocm", return_value=(None, None)), \
                patch.object(maya, "run", side_effect=AssertionError("--check installs nothing")), \
                patch.object(maya, "fail", side_effect=SystemExit) as stop:
            self.a.check = True
            with self.assertRaises(SystemExit):
                maya.check_pc(self.a)
        hint = stop.call_args.args[1]
        self.assertIn(maya.THEROCK_INDEX, hint)
        self.assertIn(f"rocm[libraries,devel,device-gfx1151]=={maya.THEROCK_VERSION}", hint)

    def test_setup_installs_rocm_into_the_venv_then_checks_again(self):
        found = iter([(None, None), (self.rocm, self.rocm / "bin"), (self.rocm, self.rocm / "bin")])
        with patch.object(maya, "windows_rocm", side_effect=lambda: next(found)), \
                patch.object(maya, "run") as pip, patch.object(sys, "base_prefix", "/somewhere/else"):
            pc = maya.check_pc(self.a)
        cmd = pip.call_args.args[0]
        self.assertEqual(cmd[:4], [sys.executable, "-m", "pip", "install"])
        self.assertIn(maya.THEROCK_INDEX, cmd)
        self.assertEqual(pc["rocm"], str(self.rocm))

    def test_check_needs_visual_studio(self):
        with patch.dict(os.environ, {"ROCM_PATH": str(self.rocm)}), \
                patch.object(maya.S, "find_vcvars", return_value=None):
            with self.assertRaises(SystemExit):
                maya.check_pc(self.a)

    def test_windows_build_uses_therock_clang_and_ninja(self):
        with patch.dict(os.environ, {"ROCM_PATH": str(self.rocm)}):
            pc = maya.check_pc(self.a)
        maya.BUILD.mkdir()
        for dll in ("amdhip64_7.dll", "amd_comgr0702.dll", "rocm_kpack.dll"):
            (self.rocm / "bin" / dll).touch()
        with patch.object(maya, "pick_cmake", return_value="cmake"), \
                patch.object(maya, "venv_tool", return_value="C:/maya/.venv/Scripts/ninja.exe"), \
                patch.object(maya, "cmake_steps", return_value=None) as build:
            meta = maya.compile_engine_hip(pc, self.root / "llama", "source-sha")
        conf, _, env, bat = build.call_args.args
        self.assertEqual(build.call_args.kwargs["vcvars"], Path("C:/VS/vcvars64.bat"))
        # the HIP runtime it was built with sits next to maya.exe (else System32's, the driver's, loads first);
        # the libraries stay in lib_dirs
        self.assertEqual(sorted(p.name for p in maya.EXE.parent.glob("*.dll")),
                         ["amd_comgr0702.dll", "amdhip64_7.dll", "rocm_kpack.dll"])
        root = self.rocm.resolve().as_posix()
        self.assertEqual(conf[1:3], ["-G", "Ninja"])
        for want in (f"-DCMAKE_CXX_COMPILER={root}/lib/llvm/bin/clang++.exe",
                     f"-DCMAKE_C_COMPILER={root}/lib/llvm/bin/clang.exe",
                     f"-DCMAKE_HIP_COMPILER={root}/lib/llvm/bin/clang++.exe",
                     f"-DCMAKE_HIP_COMPILER_ROCM_ROOT={root}",
                     "-DSTRATA_ENABLE_HIP=ON", "-DSTRATA_ENABLE_CUDA=OFF", "-DSTRATA_PREFILL_MMQ=ON",
                     "-DSTRATA_PORTABLE=ON", "-DCMAKE_HIP_ARCHITECTURES=gfx1151"):
            self.assertIn(want, conf)
        if " " not in root:
            self.assertIn(f"-DCMAKE_HIP_FLAGS=--rocm-path={root} --rocm-device-lib-path={root}/lib/llvm/amdgcn/bitcode",
                          conf)
        self.assertEqual(env["HIP_DEVICE_LIB_PATH"], str(self.rocm.resolve() / "lib/llvm/amdgcn/bitcode"))
        self.assertEqual(env["HIP_PATH"], str(self.rocm.resolve()))
        self.assertTrue(bat.endswith(".bat"))
        self.assertEqual(meta["lib_dirs"], [str(self.rocm.resolve() / "bin")])

    def hip_sdk(self):
        """AMD's HIP SDK for Windows' layout: clang, hipInfo and the DLLs in bin, the device libraries in amdgcn."""
        sdk = self.root / "Program Files/AMD/ROCm/7.2"
        for f in ("bin/clang++.exe", "bin/clang.exe", "bin/hipcc.exe", "bin/hipblas.dll", "lib/hipblas.lib"):
            (sdk / f).parent.mkdir(parents=True, exist_ok=True)
            (sdk / f).touch()
        return sdk

    def test_hip_sdk_found_by_hip_path_and_program_files(self):
        sdk = self.hip_sdk()
        old = self.root / "Program Files/AMD/ROCm/6.4/bin"
        old.mkdir(parents=True)
        (old / "clang++.exe").touch()
        clean = {k: v for k, v in os.environ.items() if k not in ("ROCM_PATH", "ROCM_VENV", "HIP_PATH")}
        with patch.object(maya, "rocm_sdk", return_value=None):
            with patch.dict(os.environ, {**clean, "HIP_PATH": str(sdk) + os.sep}, clear=True):
                self.assertEqual(maya.windows_rocm(), (sdk.resolve(), sdk.resolve() / "bin"))
            with patch.dict(os.environ, {**clean, "ProgramFiles": str(self.root / "Program Files")}, clear=True):
                self.assertEqual(maya.windows_rocm(), (sdk.resolve(), sdk.resolve() / "bin"))   # the newest
            with patch.dict(os.environ, {**clean, "ProgramFiles": str(self.root / "none")}, clear=True):
                self.assertEqual(maya.windows_rocm(), (None, None))
        self.assertEqual(maya.hip_clang(sdk), sdk / "bin/clang++.exe")

    def test_hip_sdk_build_in_a_folder_with_a_space(self):
        sdk = self.hip_sdk()
        with patch.dict(os.environ, {"ROCM_PATH": str(sdk)}):
            pc = maya.check_pc(self.a)
        maya.BUILD.mkdir()
        with patch.object(maya, "pick_cmake", return_value="cmake"), \
                patch.object(maya, "venv_tool", return_value="C:/maya/.venv/Scripts/ninja.exe"), \
                patch.object(maya, "cmake_steps", return_value=None) as build:
            maya.compile_engine_hip(pc, self.root / "llama", "source-sha")
        conf, _, env, _ = build.call_args.args
        root = sdk.resolve()
        self.assertIn(f"-DCMAKE_HIP_COMPILER={(root / 'bin/clang++.exe').as_posix()}", conf)
        self.assertIn(f"-DCMAKE_C_COMPILER={(root / 'bin/clang.exe').as_posix()}", conf)
        self.assertFalse([x for x in conf if x.startswith("-DCMAKE_HIP_FLAGS=")])   # "Program Files": the env instead
        self.assertEqual(env["HIP_PATH"], str(root))
        self.assertEqual(env["HIP_DEVICE_LIB_PATH"], str(root / "amdgcn/bitcode"))

    def test_windows_apu_config(self):
        tables = self.root / "tools/hip"
        tables.mkdir(parents=True)
        (tables / "gfx1151-glm-hipblaslt-100202.txt").write_text("STRATA_HIPBLASLT_TUNING_V1 gfx1151 100202\n")
        with patch.dict(os.environ, {"ROCM_PATH": str(self.rocm)}):
            pc = maya.check_pc(self.a)
        p = maya.write_config(self.a, pc, {"lib_dirs": [str(self.rocm / "bin")]}, self.root / "pack", "Maya-L", 32768,
                              self.root / "data", None)
        cfg = maya.read_json(p)
        self.assertEqual(p.name, "maya-maya-l-hip.json")
        self.assertEqual((cfg["backend"], cfg["gpu"], cfg["exe"]), ("hip", [0], str(self.root / "build-hip/maya.exe")))
        self.assertEqual(cfg["lib_dirs"], [str(self.rocm / "bin")])
        env = cfg["env"]
        self.assertEqual(env["STRATA_GLM_RESERVE_MB"], "3072")    # the desktop runs on the APU's GPU too
        self.assertEqual(env["STRATA_GLM_PREFILL_MB"], "6144")    # 32 GB Windows + 96 GB the GPU's
        self.assertEqual(env["STRATA_GLM_PREFILL_SUB"], "1024")
        self.assertEqual(env["STRATA_GLM_SPLIT"], "0")
        self.assertNotIn("STRATA_GLM_POOL_GB", env)


class Vs2026Hint(unittest.TestCase):
    """#544: a HIP build with VS 2026's Build Tools alone - its folder is named 18, 2019 / 2022 by their year."""

    def test_vs_2026(self):
        vs = r"C:\Program Files (x86)\Microsoft Visual Studio\{}\BuildTools\VC\Auxiliary\Build\vcvars64.bat"
        self.assertTrue(maya.vs_2026(vs.format("18")))
        self.assertFalse(maya.vs_2026(vs.format("2022")))
        self.assertFalse(maya.vs_2026(vs.format("2019")))
        self.assertFalse(maya.vs_2026(None))
        self.assertIn("2022", maya.VS2026_HIP_HINT)


if __name__ == "__main__":
    unittest.main()
